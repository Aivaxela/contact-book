// Project:             lab12
// Class:               ITCS1820 Java Programming I
// Date:                4/4/2025
// Author:              Marcum
// Description:         Exception Handling
package marcum;

public class ContactException extends Exception {
    public ContactException(String message) {
        super(message);
    }
}
